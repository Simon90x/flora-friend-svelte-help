<script>
     import '../app.css';
  // ...existing code...
</script>

<h2>Home</h2>
<p>Benvenuto su Flora Friend! 🌱</p>
