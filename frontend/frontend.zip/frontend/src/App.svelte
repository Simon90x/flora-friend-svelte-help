<script>
  import Layout from './lib/Layout.svelte';
  import Sidebar from './lib/Sidebar.svelte';
  import Dashboard from './lib/Dashboard.svelte';
  import PlantDetail from './lib/PlantDetail.svelte';
  import UserProfile from './lib/UserProfile.svelte';
  import UserStatus from './lib/UserStatus.svelte';
  import Login from './lib/Login.svelte';
  import { user } from './lib/stores';
  import { page } from './lib/navigation';
  import { configureAuthDependency } from './lib/api.js';

  let currentUser;
  $: user.subscribe(u => currentUser = u);
  let currentPage = 'dashboard';
  $: page.subscribe(p => currentPage = p);

  const authDependency = {
    getCurrentUser() {
      return $user;
    },
    getIsDemoSession() {
      // Definisci qui la logica per la modalità demo, ad esempio in base a una flag in localStorage o ambiente
      return $user && $user.id === 'demo';
    }
  };

  configureAuthDependency(authDependency);
</script>

<Layout>
  <Sidebar />
  <UserStatus />
  {#if !currentUser}
    <Login />
  {:else}
    {#if currentPage === 'dashboard'}
      <Dashboard />
    {:else if currentPage === 'plantDetail'}
      <PlantDetail />
    {:else if currentPage === 'profile'}
      <UserProfile />
    {:else}
      <Dashboard />
    {/if}
  {/if}
</Layout>

<style>
</style>
